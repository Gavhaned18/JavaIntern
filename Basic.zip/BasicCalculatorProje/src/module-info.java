/**
 * 
 */
/**
 * 
 */
module BasicCalculatorProje {
}