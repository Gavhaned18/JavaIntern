package chatApp;
import java.io.*;
import java.net.*;

public class Client {
    private static final String SERVER_IP = "localhost"; // or IP of server
    private static final int PORT = 1234;

    public static void main(String[] args) {
        try (Socket socket = new Socket(SERVER_IP, PORT)) {
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in));

            // Read from server
            new Thread(() -> {
                try {
                    String msgFromServer;
                    while ((msgFromServer = input.readLine()) != null) {
                        System.out.println(msgFromServer);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();

            // Send to server
            String msgToServer;
            while ((msgToServer = consoleInput.readLine()) != null) {
                output.println(msgToServer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
